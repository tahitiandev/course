import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Plats } from 'src/app/models/plats';
import { Storage } from '@ionic/storage';
import { UtilityService } from 'src/app/services/utility.service';

@Component({
  selector: 'app-ingredient',
  templateUrl: './ingredient.page.html',
  styleUrls: ['./ingredient.page.scss'],
})
export class IngredientPage implements OnInit {

  plats : Plats[];
  libelle : string;
  private _platRechercher : Plats;
  get platRechecher(){
    return this._platRechercher;
  }
  set platRechercher(values : Plats){
    this._platRechercher = values
  }

  platDetail : Plats;
  ingredients = [];

  constructor(private snap : ActivatedRoute,
              private storage : Storage,
              private utility : UtilityService) { }

  ngOnInit() {
    this.loadPlatsFromLocalStorage();
  }

  private async loadPlatsFromLocalStorage(){

    const plats = await this.storage.get(this.utility.localstorage.Plats)
    this.plats = plats
    await this.getLibelle();
    await this.getPlatByLibelle(this.libelle)
    await this.getIngredient(this.platDetail.codeArticle)

  }

  private async getLibelle(){

    const libelle = await this.snap.snapshot.params['libelle']
    this.libelle = libelle

  }


  private async getPlatByLibelle(libelle : string){

    const plat = await this.plats.find(s => {
      return s.libelle === libelle
    })

    this.platDetail = plat


  }

  private async getIngredient(codeArticle : any []){

    const article = await this.storage.get(this.utility.localstorage.articles)

    for(var x = 0; x < codeArticle.length; x++){
                    
      article.find(s => {
        if(s.code === codeArticle[x]){
          this.ingredients.push(s)
        }
      })

    } //for

  }//getIngredient

}
