import { Component, OnInit } from '@angular/core';
import { ArticlesService } from 'src/app/services/articles.service';
import { Storage } from '@ionic/storage';
import { UtilityService } from 'src/app/services/utility.service';
import { FamilleArticle } from 'src/app/models/articles';

@Component({
  selector: 'app-famille-list',
  templateUrl: './famille-list.page.html',
  styleUrls: ['./famille-list.page.scss'],
})
export class FamilleListPage implements OnInit {

  constructor(private article : ArticlesService,
              private storage : Storage,
              private utility : UtilityService) { }

  familles : FamilleArticle [] = [];

  ngOnInit() {
    this.getFamilleFromLocalStorage()
  }

  async getFamilleFromLocalStorage(){
    const familles = await this.storage.get(this.utility.localstorage['famille d\'articles'])
    this.familles = familles
  }

}
