import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { Articles } from 'src/app/models/articles';
import { UtilityService } from 'src/app/services/utility.service';

@Component({
  selector: 'app-article-details',
  templateUrl: './article-details.page.html',
  styleUrls: ['./article-details.page.scss'],
})
export class ArticleDetailsPage implements OnInit {

  constructor(private snap : ActivatedRoute,
              private storage : Storage,
              private utility : UtilityService,
              private nav : NavController) { }
  

  articleId :  number;
  article : Articles;

  ngOnInit() {
    this.articleId = this.snap.snapshot.params['id']
    this.getArticleById(this.articleId)
  }

  async getArticleById(id : number){
    const articles = await this.storage.get(this.utility.localstorage.articles)
    this.article = articles[id]
  }


}
